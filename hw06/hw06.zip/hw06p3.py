#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Oct  8 18:40:32 2026

@author: anna
"""
import numpy as np
import matplotlib.pyplot as plt

def randomSquareMatrix(n):
    n = 10
    A = [[]] * n
    for i in range(n):
        A[i] = [0] * n
        for j in range(n):
            A[i][j] = np.random.randn()
            
    return A

def randomColumnMatrix():
    n = 10
    b = [0] * n
    for i in range(n):
        b[i] = np.random.randn()
    
    return b

Ra = np.array([])
Ca = np.array([])
R = np.array([])

for k in range(1000):
    A = np.array(randomSquareMatrix(10))
    b = np.array(randomColumnMatrix())
    
    Ainv = np.linalg.inv(A)
    
    x = np.dot(Ainv, b)
    r = np.dot(A, x) - b
    
    print(r)
    
    ra = np.abs(np.linalg.det(A)) / np.abs(np.linalg.norm(A))
    ca = np.abs(np.linalg.det(A)) * np.abs(np.linalg.det(Ainv))
    residNorm = np.linalg.norm(r)
    
    Ra = np.append(Ra, ra)
    Ca = np.append(Ca, ca)
    R = np.append(R, residNorm)

plt.scatter(np.log(Ra), np.log(Ca))
plt.ylabel("Ca")
plt.xlabel("Ra")
plt.show()
plt.scatter(np.log(R), np.log(Ca))
plt.ylabel("Ca")
plt.xlabel("Residual Norms")
plt.show()